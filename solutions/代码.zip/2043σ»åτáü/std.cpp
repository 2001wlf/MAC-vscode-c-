#include <iostream>
#include <cmath>
#include <algorithm>
#include <iomanip>
#include <vector>
#include <string>
#include <string.h>
#include<cstdio>
#include<cstdlib>
using namespace std;
int main()
{
   // freopen("1.in.txt","r",stdin);
    //freopen("1.out.txt","w",stdout);
    int n;
    cin>>n;
    string k;
    while(n--)
    {
        cin>>k;
        int res=3;
        int flag=0;
        int len=k.size();
        if(len<8||len>16)
        {
            cout<<"NO"<<endl;
            continue;
        }
        int a[4];
        memset(a,0,sizeof(a));
        for(int i=0;i<len;i++)
        {
            if(k[i]>='0'&&k[i]<='9')
            {
                a[0]=1;
            }
            if(k[i]>='A'&&k[i]<='Z')
            {
                a[1]=1;
            }
            if(k[i]>='a'&&k[i]<='z')
            {
                a[2]=1;
            }
            if(k[i]=='~'||k[i]=='!'||k[i]=='@'||k[i]=='#'||k[i]=='$'||k[i]=='%'||k[i]=='^')
            {
                a[3]=1;
            }
        }
        int sum=0;
        for(int i=0;i<=3;i++)
        {
            sum+=a[i];
        }
        if(sum>=3)
        {
            cout<<"YES"<<endl;
        }
        else cout<<"NO"<<endl;
    }
    return 0;
}