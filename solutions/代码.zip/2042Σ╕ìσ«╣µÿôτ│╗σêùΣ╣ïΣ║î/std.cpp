#include <iostream>
#include <cmath>
#include <algorithm>
#include <iomanip>
#include <vector>
#include <string>
#include <string.h>
#include<cstdio>
#include<cstdlib>
using namespace std;
int main()
{
    //freopen("5.in.txt","r",stdin);
    //freopen("5.out.txt","w",stdout);
    int n;
    cin>>n;
    int a;
    while(n--)
    {
        cin>>a;
        int res=3;
        for(int i=1;i<=a;i++)
        {
            res=(res-1)*2;
        }
        cout<<res<<endl;
    }
    return 0;
}