#include <iostream>
#include <cmath>
#include <algorithm>
#include <iomanip>
#include <vector>
#include <string>
#include <string.h>
#include <cstdio>
#include <cstdlib>
using namespace std;
typedef long long ll;

ll a[55];
int main()
{
  //  freopen("5.in.txt","r",stdin);
   // freopen("5.out.txt","w",stdout);
    a[1]=1;
    a[2]=2;
    a[3]=3;
    for(int i=4;i<=52;i++)
    {
        a[i]=a[i-1]+a[i-2];
    }
    int n;
    while(cin>>n)
    {
        cout<<a[n]<<endl;
    }
    return 0;
}