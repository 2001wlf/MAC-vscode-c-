#include<iostream>
#include<algorithm>
#include<cstring>

using namespace std;
int cur[41];
int main()
{
   // freopen("5.in.txt","r",stdin);
   // freopen("5.out.txt","w",stdout);
    cur[1]=1;
    cur[2]=1;
    for(int i=3; i<=40; i++)
    {
        cur[i]=cur[i-1]+cur[i-2];
    }
    int n;
    while(cin>>n&&n)
    {
        for(int i=1; i<=n; i++)
        {
            int m;
            cin>>m;
            cout<<cur[m]<<endl;
        }
    }
    return 0;
}