#include <iostream>
#include <cmath>
#include <algorithm>
#include <iomanip>
#include <vector>
#include <string>
#include <string.h>
#include <cstdio>
#include <cstdlib>
//#include<windows.h>
using namespace std;
long long  a[1000];
long long factor[1000];
int main()
{
    //freopen("5.in.txt","r",stdin);
    //freopen("5.out.txt","w",stdout);
    factor[0]=1;
    factor[1]=1;
    for(int i=2;i<=22;i++)
    {
        factor[i]=factor[i-1]*i;
    }
    a[1]=0;
    a[2]=1;
    for(int i=3;i<=22;i++)
    {
        a[i]=(a[i-2]+a[i-1])*(i-1);
    }
    int n;
    cin>>n;
    while(n--)
    {
        int total=0;
        int select=0;
        cin>>total>>select;
        int s=total-select;
        long long res=1;
        res*=factor[total]/factor[s]/factor[total-s];
        res*=a[select];
        cout<<res<<endl;
    }
    //system("pause");
    return 0;
}