#include<iostream>
#include<cstdio>
#include<iterator>
#include<cstring>
#include<string>
#include<stack>
#include<algorithm>
#include<set>
#include<cmath>
#include<map>
#include<deque>
#include<queue>
#include<vector>
#include<iomanip>
#include<unordered_map>
using namespace std;
#define endl '\n'
#define sin scanf
#define sout printf
#define all(x) (x).begin(),(x).end() 
#define PII pair<int,int> 
typedef long long ll;
typedef unsigned long long ull;
const int INF=0x3f3f3f3f;
const int Mod=1e9+7;
const int maxn = 1e6+10;
char spe[10]={'~','!','@','#','$','%','^'};
signed main()
{
	ios::sync_with_stdio(false);
	cin.tie(0),cout.tie(0);
	freopen("5.in.txt","w",stdout);
	srand(time(0));
	int n=rand()%30;
	//cout<<n;
	//cout<<endl;
	for(int i=1;i<=n;i++)
	{
		int len;
		len1: len=rand()%40;
		if(len==0)
			goto len1;
		cout<<len<<endl;
	}
	return 0;
}	