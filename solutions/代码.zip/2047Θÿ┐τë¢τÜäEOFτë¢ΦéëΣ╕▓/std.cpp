#include <iostream>
#include <cmath>
#include <algorithm>
#include <iomanip>
#include <vector>
#include <string>
#include <string.h>
#include <cstdio>
#include <cstdlib>
using namespace std;
typedef long long ll;
ll a[55];
int main()
{
    //freopen("5.in.txt","r",stdin);
    //freopen("5.out.txt","w",stdout);
    a[1]=3;
    a[2]=8;
    for(int i=3;i<=45;i++)
    {
        a[i]=a[i-1]*2+a[i-2]*2;
    }
    int n;
    while(cin>>n)
    {
        cout<<a[n]<<endl;
    }
    return 0;
}