#include <iostream>
#include <cmath>
#include <algorithm>
#include <iomanip>
#include <vector>
#include <string>
#include <string.h>
#include<cstdio>
#include<cstdlib>
using namespace std;
bool check(int a,int b)
{
    int sum1=1;
    int sum2=1;
    int a1=a;
    int b1=b;
    int k=2;
    while(a1)
    {
        if(a1==k)
        {
            break;
        }
        if(a1%k==0)
        {
            sum1+=k;
        }
        k++;
    }
    k=2;
    while(b1)
    {
        if(b1==k)
        {
            break;
        }
        if(b1%k==0)
        {
            sum2+=k;
        }
        k++;
    }
    if(sum1==b&&sum2==a)
    {
        return true;
    }
    return false;
}
int main()
{
    int a,b;
    int n;
    //freopen("1.in.txt","r",stdin);
    //freopen("1.out.txt","w",stdout);
    cin>>n;
    while(n--)
    {
        cin>>a>>b;
       // cout<<a<<" "<<b<<endl;
        if(check(a,b))
        {
            cout<<"YES";
        }
        else cout<<"NO";
        cout<<endl;
    }
    return 0;
}