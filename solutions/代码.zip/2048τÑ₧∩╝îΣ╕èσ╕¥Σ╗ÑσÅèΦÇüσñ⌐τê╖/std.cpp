#include <iostream>
#include <cmath>
#include <algorithm>
#include <iomanip>
#include <vector>
#include <string>
#include <string.h>
#include <cstdio>
#include <cstdlib>
using namespace std;
typedef long long ll;

ll a[100][2]; 
int main()
{
   // freopen("5.in.txt","r",stdin);
   // freopen("5.out.txt","w",stdout);
    a[1][0]=1;
    a[1][1]=0;
    a[2][0]=2;
    a[2][1]=1;
    for(int i=3;i<=20;i++)
    {
        a[i][0]=i*a[i-1][0];
        a[i][1]=(i-1)*a[i-1][1]+(i-1)*a[i-2][1];
    }
    int n;
    int q;
    cin>>q;
    while(q--)
    {
        cin>>n;
        cout<<fixed<<setprecision(2)<<double(a[n][1])/double(a[n][0])*100<<"%"<<endl;
    }
    return 0;
}