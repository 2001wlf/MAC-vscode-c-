#include <iostream>
#include <cmath>
#include <algorithm>
#include <iomanip>
#include <vector>
#include <string>
#include <string.h>
#include<cstdio>
#include<cstdlib>
using namespace std;
long long a[51];
int main()
{
   // freopen("5.in.txt","r",stdin);
    //freopen("5.out.txt","w",stdout);
    a[1]=0;
    a[2]=1;
    a[3]=2;
    for(int i=4;i<=50;i++)
    {
        a[i]=a[i-1]+a[i-2];
    }
    int n;
    cin>>n;
    int k;
    int m;
    for(int i=1;i<=n;i++)
    {
        cin>>k;
        cin>>m;
        cout<<a[m-k+1]<<endl;
    }
    return 0;
}