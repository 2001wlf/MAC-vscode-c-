#include <iostream>
#include <string>
#include <cstring>
#include <string.h>
using namespace std;
typedef long long ll;
ll n;
ll b[100]; 
ll a[100];
ll pow1(ll n)
{
    ll res=1;
    for(ll i=0;i<n;i++)
    {
        res*=2;
    }
    return res;
}
int main()
{
   // freopen("1.in.txt","r",stdin);
   // freopen("1.out.txt","w",stdout);
    b[0]=3;
    for(int i=1;i<=51;i++)
    {
        a[i]=pow1(i)-a[i-1];
        b[i]=3*a[i];        
    }
    int n;
    while(cin>>n)
    {
        cout<<b[n-1]<<endl;
    }
    return 0;   
}
